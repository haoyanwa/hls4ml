//Numpy array shape [3]
//Min -0.300000011921
//Max 0.200000002980
//Number of zeros 1

#ifndef B7_H_
#define B7_H_

[[intel::fpga_register]] static constexpr b7_t b7 = {{-0.3000000119, -0.0000000000, 0.2000000030}};

#endif
