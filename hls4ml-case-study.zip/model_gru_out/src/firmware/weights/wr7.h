//Numpy array shape [3, 3]
//Min -1.100000023842
//Max 1.000000000000
//Number of zeros 2

#ifndef WR7_H_
#define WR7_H_

[[intel::fpga_register]] static constexpr wr7_t wr7 = {{0.2000000030, -0.3000000119, 0.0000000000, -0.6000000238, 1.0000000000, 0.5000000000, 0.0000000000, -1.1000000238, -0.5000000000}};

#endif
