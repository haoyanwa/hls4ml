//Numpy array shape [2, 3]
//Min -0.800000011921
//Max 1.000000000000
//Number of zeros 0

#ifndef W7_H_
#define W7_H_

[[intel::fpga_register]] static constexpr w7_t w7 = {{0.6999999881, 0.3000000119, -0.8000000119, -0.6999999881, -0.4000000060, 1.0000000000}};

#endif
