//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B8_H_
#define B8_H_

[[intel::fpga_register]] static constexpr b8_t b8 = {{0, 0, 0, 0}};

#endif
