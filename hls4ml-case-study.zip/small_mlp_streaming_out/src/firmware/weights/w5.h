//Numpy array shape [4, 2]
//Min -0.464387208223
//Max 0.740611732006
//Number of zeros 0

#ifndef W5_H_
#define W5_H_

[[intel::fpga_register]] static constexpr w5_t w5 = {{-0.0260112882, 0.7110052705, 0.4365188479, -0.4643872082, -0.0511002541, 0.4318782687, 0.7406117320, 0.7390003800}};

#endif
