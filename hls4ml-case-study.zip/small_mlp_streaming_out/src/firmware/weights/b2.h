//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B2_H_
#define B2_H_

[[intel::fpga_register]] static constexpr b2_t b2 = {{0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000}};

#endif
