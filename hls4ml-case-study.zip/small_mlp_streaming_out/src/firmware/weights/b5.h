//Numpy array shape [2]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 2

#ifndef B5_H_
#define B5_H_

[[intel::fpga_register]] static constexpr b5_t b5 = {{0.0000000000, 0.0000000000}};

#endif
