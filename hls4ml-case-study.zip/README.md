## Usage of sideband signal in StreamingBeat

Use `stop-of-packet` and `end-of-packet` signal to synchronize across multiple kernels.

- /src/firmware/myproject.h

```c++
using InputBeatT = sycl::ext::intel::experimental::StreamingBeat<
    input_t,     // type carried over this Avalon streaming interface's data signal.
    true,         // enable startofpacket and endofpacket signals
    true>;       // to enable the empty signal
```

### Utility functions to extract type during compile time

- firmware\nnet_utils\nnet_types.h

```c++
// Helper to extract DataT from StreamingBeat
template <typename T> struct ExtractDataType { typedef T value_type; };

template <typename DataT, bool EnableSOP, bool EnableEmpty>
struct ExtractDataType<sycl::ext::intel::experimental::StreamingBeat<DataT, EnableSOP, EnableEmpty>> {
    typedef DataT value_type;
};

// This is a helper to extract the value_type of a pipe
template <typename T> struct ExtractPipeType { typedef T value_type; };

template <template <class, class, int32_t, class, typename...> class PipeClass, class PipeName, class PipeDataT,
          int32_t kPipeMinCapacity, class PipeProperties, typename... Args>
struct ExtractPipeType<PipeClass<PipeName, PipeDataT, kPipeMinCapacity, PipeProperties,
                                 Args...>> // specialization
{
    typedef PipeDataT value_type;
};
```

## Modified Dense and ReLU layers

Key changes are explained in the slides. Similar changes can be applied to other layers and functions.
The key points are:
1. use sideband signals (sop and eop) for synchronization
2. use always-run kernel, i.e. the while loop
3. non-blocking pipe read to ensure task sequence I/O does not block compute
4. extract pipe datatype during compile time

- small_mlp_streaming_out/src/firmware/nnet_utils/nnet_dense_stream.h

```c++
template <class data_pipe, class res_pipe, typename CONFIG_T>
[[intel::use_stall_enable_clusters]] void dense_resource_stream(const typename CONFIG_T::weight_t weights, const typename CONFIG_T::bias_t biases) {
    using namespace nnet;
    using DataT = typename ExtractDataType<typename ExtractPipeType<data_pipe>::value_type>::value_type;
    using ResT = typename ExtractDataType<typename ExtractPipeType<res_pipe>::value_type>::value_type;
    
    [[intel::fpga_register]] typename ExtractPipeType<res_pipe>::value_type resbeat;
    // [[intel::fpga_register]] ResT res;

    bool keep_going = true;
    bool did_read_input;
    [[intel::initiation_interval(1)]]
    while (keep_going) {
        did_read_input = false;
        [[intel::fpga_register]] auto databeat = data_pipe::read(did_read_input);

        if (did_read_input) {
            dense_resource<DataT, ResT, CONFIG_T>(databeat.data, resbeat.data, weights, biases);

            resbeat.sop = databeat.sop;
            resbeat.eop = databeat.eop;

            res_pipe::write(resbeat);
            keep_going = !databeat.eop;
        }
    }
}
```

- small_mlp_streaming_out/src/firmware/nnet_utils/nnet_activation_stream.h

```c++
// *************************************************
//       ReLU Activation
// *************************************************

template <class data_pipe, class res_pipe, typename CONFIG_T> 
[[intel::use_stall_enable_clusters]] void relu_stream() {
    using namespace nnet;
    // using DataT = typename ExtractDataType<typename ExtractPipeType<data_pipe>::value_type>::value_type;
    using ResT = typename ExtractDataType<typename ExtractPipeType<res_pipe>::value_type>::value_type;
    
    [[intel::fpga_register]] typename ExtractPipeType<res_pipe>::value_type out_data;

    bool keep_going = true;

ReLUActLoop:
    [[intel::initiation_interval(1)]]
    while(keep_going) {
        for (int i = 0; i < CONFIG_T::n_in / std::tuple_size<ResT>{}; i++) {
            [[intel::fpga_register]] auto in_data = data_pipe::read();
ReLUPackLoop:
            #pragma unroll
            for (int j = 0; j < std::tuple_size<ResT>{}; j++) {
                if (in_data.data[j] > 0)
                    out_data.data[j] = in_data.data[j];
                else
                    out_data.data[j] = 0;
            }

            out_data.sop = in_data.sop;
            out_data.eop = in_data.eop;
            res_pipe::write(out_data);

            keep_going = !in_data.eop;
        }
    }
}
```

## Added DMA kernels and pipes for hardware run

- model_gru_out/src/firmware/myproject.h

```c++
template <class srcType, class dest_pipe, size_t SIZE> 
struct DMA_convert_data {};

template <class src_pipe, class dstType, size_t SIZE> 
struct DMA_convert_data_back {};

```

## Testbench changes to use DMAs for input and output

- model_gru_out/src/myproject_test.cpp

Using DMAs for transferring data is currently a test for hardware run but can be adapted to emulation/simulation as well (by providing a wrapper that automatically selects USM+DMA/ or host pipe). Allocate buffers and move data between host and device.

```c++
    // hls-fpga-machine-learning insert zero
    // (haoyanwa) change the input and output to device ptr.
#if defined(IS_BSP)
    float *vals_device_ptr = sycl::malloc_device<float>(kinputSz, q);
    if (vals_device_ptr == nullptr) {
        std::cerr << "ERROR: device allocation failed for input\n";
        return 1;
    }
    float *output_device_ptr = sycl::malloc_device<float>(kOutputSz, q);
    if (output_device_ptr == nullptr) {
        std::cerr << "ERROR: device allocation failed for output\n";
        return 1;
    }    
#else
    float *vals_device_ptr = sycl::malloc_shared<float>(kinputSz, q, sycl::property_list{buffer_location(kInputBufferLocation)});
    float *output_device_ptr = sycl::malloc_shared<float>(kOutputSz, q, sycl::property_list{buffer_location(kOutputBufferLocation)});
#endif

    // copy the input data to the device memory and wait for the copy to finish
    q.memcpy(vals_device_ptr, vals, kinputSz * sizeof(float)).wait();

    // nnet::convert_data<float, Conv1DInputPipe, N_INPUT_1_1*N_INPUT_2_1>(q, vals);
    // (haoyanwa) changing to DMA kernel invocation.
    q.single_task(DMA_convert_data<float, Conv1DInputPipe, kinputSz>{vals_device_ptr});
    q.single_task(Myproject{});
    // hls-fpga-machine-learning convert output
    // nnet::convert_data_back<Layer4OutPipe, float, N_OUT_4>(q, outputs);
    // (haoyanwa) changing to DMA kernel invocation.
    q.single_task(DMA_convert_data_back<Layer4OutPipe, float, kOutputSz>{output_device_ptr}).wait();
    q.memcpy(outputs, output_device_ptr, kOutputSz * sizeof(float)).wait();
```